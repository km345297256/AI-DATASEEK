--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 18.6 (Debian 18.6-1.pgdg13+2)
-- Dumped by pg_dump version 18.6 (Debian 18.6-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


\unrestrict (null)
\connect postgres
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: empty; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.empty (
    label text
);


--
-- Name: measurements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.measurements (
    id bigint,
    amount numeric(38,18),
    signal double precision,
    label text,
    active boolean,
    optional text
);


--
-- Data for Name: empty; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.empty (label) FROM stdin;
\.
COPY public.empty (label) FROM '$$PATH$$/3440.dat';

--
-- Data for Name: measurements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.measurements (id, amount, signal, label, active, optional) FROM stdin;
\.
COPY public.measurements (id, amount, signal, label, active, optional) FROM '$$PATH$$/3439.dat';

--
-- PostgreSQL database dump complete
--

